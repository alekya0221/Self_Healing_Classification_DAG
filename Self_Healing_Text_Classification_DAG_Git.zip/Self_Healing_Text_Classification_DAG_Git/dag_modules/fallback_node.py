# -*- coding: utf-8 -*-
"""fallback_node.py — Handles fallback interaction during low-confidence predictions"""

class FallbackNode:
    def __init__(self, label_map):
        self.label_map = label_map

    def run(self, prediction):
        initial_idx = prediction["label"]
        initial_label = self.label_map[initial_idx]

        #print(f"\n[FallbackNode] Model wasn’t confident enough (only {prediction['confidence']}%) on this input:")
        #print(f"Input: {prediction['input']}")
        #print(f"[FallbackNode] Could you clarify your intent? Was this a {initial_label.lower()} review?")

        clarification = input("User: ").strip().lower()
        corrected_idx = initial_idx  # default to original prediction

        # Accept if user types 'yes' or types the label itself (e.g., 'neutral')
        if "yes" in clarification or clarification == initial_label.lower():
            pass  # keep the initial label
        else:
            print("Please select the correct label:")
            for idx, label in self.label_map.items():
                print(f"{idx}: {label}")
            while True:
                try:
                    user_selection = int(input("Your selection: "))
                    if user_selection in self.label_map:
                        corrected_idx = user_selection
                        break
                    else:
                        print(" Invalid label number. Try again.")
                except ValueError:
                    print(" Please enter a valid integer label.")

        return {
            "input": prediction["input"],
            "label": corrected_idx,
            "label_text": self.label_map[corrected_idx],
            "confidence": "user-clarified",
            "clarified_input": clarification,
            "final_decision": {
                "label": corrected_idx,
                "source": "clarified"
            }
        }
